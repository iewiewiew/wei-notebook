﻿using System;
using System.IO;
using System.IO.Compression;

namespace custzipRWApp
{
    class Program
    {
        static void Main(string[] args)
        {
            using (FileStream fsout = new FileStream("test.zip", FileMode.OpenOrCreate, FileAccess.ReadWrite))
            {
                // 创建zip文档实例
                ZipArchive archive = new ZipArchive(fsout, ZipArchiveMode.Create);
                // 创建根目录下的文件
                ZipArchiveEntry entry1 = archive.CreateEntry("第一项.txt", CompressionLevel.Optimal);
                // 向文件写入内容
                using (StreamWriter wt = new StreamWriter(entry1.Open()))
                {
                    wt.WriteLine("这是压缩的第一个文件。");
                }
                // 创建位于相对目录的文件
                ZipArchiveEntry entry2 = archive.CreateEntry("第二项\\data.txt", CompressionLevel.Optimal);
                // 向文件写入内容
                using (StreamWriter wt =new StreamWriter(entry2.Open()))
                {
                    wt.WriteLine("这是压缩的第二个文件。");
                }
                // 创建第三个文件
                ZipArchiveEntry entry3 = archive.CreateEntry("第三项/document.txt", CompressionLevel.Optimal);
                // 向文件中写入内容
                using (StreamWriter wt = new StreamWriter(entry3.Open()))
                {
                    wt.WriteLine("这是压缩的第三个文件。");
                }

                // 操作完成后，要释放zip文档对象
                archive.Dispose();
            }
        }
    }
}
